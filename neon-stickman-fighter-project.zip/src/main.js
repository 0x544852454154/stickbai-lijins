import {Game} from './core/Game.js';
const canvas=document.getElementById('game');
const fit=()=>{const s=Math.min(innerWidth/480,innerHeight/270),q=window.__game&&window.__game.settings.opt.quality,k=q!==0&&s>=1?Math.floor(s):s;canvas.style.width=480*k+'px';canvas.style.height=270*k+'px'};
(async()=>{try{await Promise.race([document.fonts.load('8px "Press Start 2P"'),new Promise(r=>setTimeout(r,1500))])}catch(e){}
  const g=window.__game=new Game(canvas);addEventListener('resize',fit);fit();await g.start();setInterval(fit,500)})();
