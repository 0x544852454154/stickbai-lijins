export class AudioManager{
  constructor(s){this.s=s;this.ctx=null;this.n=0}
  unlock(){if(this.ctx)return;try{this.ctx=new AudioContext();this.out=this.ctx.createGain();this.out.connect(this.ctx.destination);setInterval(()=>this.music(),170)}catch(e){}}
  tone(f,d,type='square',v=.2,slide=0,bus='sfx'){if(!this.ctx)return;const c=this.ctx,o=c.createOscillator(),g=c.createGain(),t=c.currentTime;o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(30,f+slide),t+d);g.gain.setValueAtTime(Math.max(.0001,v*this.s.opt[bus]),t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(this.out);o.start();o.stop(t+d)}
  noise(d,v){if(!this.ctx)return;const c=this.ctx,b=c.createBuffer(1,c.sampleRate*d,c.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*(1-i/a.length);const s=c.createBufferSource(),g=c.createGain();g.gain.value=v*this.s.opt.sfx;s.buffer=b;s.connect(g);g.connect(this.out);s.start()}
  sfx(n){const m={hit:()=>{this.noise(.08,.5);this.tone(150,.1,'square',.3,-90)},heavy:()=>{this.noise(.18,.7);this.tone(90,.25,'sawtooth',.4,-60)},block:()=>this.tone(900,.05,'triangle',.3),
    special:()=>{this.noise(.25,.3);this.tone(300,.3,'sawtooth',.25,600)},blip:()=>this.tone(660,.04,'square',.12),ok:()=>{this.tone(520,.06,'square',.15);this.tone(780,.1,'square',.15)},ko:()=>this.tone(220,.7,'sawtooth',.4,-180),bell:()=>this.tone(440,.3,'triangle',.3)};m[n]&&m[n]()}
  music(){if(!this.ctx||this.s.opt.music<=0)return;const i=this.n++%16,bass=[55,55,65,55,49,49,62,49][i%8];if(i%2===0)this.tone(bass*2,.16,'sawtooth',.18,0,'music');this.tone([220,262,330,262][i%4]*(i>7?1.2:1),.08,'square',.06,0,'music')}
}
