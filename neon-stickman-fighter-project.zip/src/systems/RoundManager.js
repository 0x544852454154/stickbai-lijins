export class RoundManager{
  constructor(training,need=2){this.training=training;this.need=need;this.wins=[0,0];this.round=0;this.winner=null;this.start()}
  start(){this.round++;this.phase='intro';this.t=0;this.time=99;this.fr=0;this.rw=-1}
  update(f1,f2){this.t++;
    if(this.phase==='intro'&&this.t>100){this.phase='fight';this.t=0}
    else if(this.phase==='fight'){if(!this.training&&++this.fr%60===0)this.time--;
      if(f1.hp<=0||f2.hp<=0||(this.time<=0&&!this.training)){this.rw=f1.hp>f2.hp?0:f2.hp>f1.hp?1:-1;if(this.rw>=0)this.wins[this.rw]++;this.phase='ko';this.t=0;return 'ko'}}
    else if(this.phase==='ko'&&this.t>150){if(this.wins.some(w=>w>=this.need)){this.phase='end';this.winner=this.wins[0]>this.wins[1]?0:1;return 'end'}this.phase='next';return 'next'}}
}
