import {CharacterManager} from '../characters/CharacterManager.js';
export class Campaign{
  constructor(mode,p1){this.mode=mode;this.p1=p1;this.n=0;this.carry=null;this.order=CharacterManager.ids.filter(i=>i!==p1).sort(()=>Math.random()-.5)}
  get arcade(){return this.mode==='arcade'}
  get over(){return this.arcade&&this.n>=4}
  options(){const boss=this.arcade&&this.n===3,ids=CharacterManager.ids,id=this.arcade&&this.n<3?this.order[this.n]:ids[Math.random()*4|0];
    return{mode:this.mode,p1:this.p1,p2:id,human2:false,diff:this.arcade?['easy','normal','hard','hard'][this.n]:(this.n<3?'normal':'hard'),hpMul:boss?1.4:1,stage:Math.random()*5|0,rounds:this.arcade?2:1,carry:this.carry,boss,campaign:this}}
}
