export class SpriteAnimator{
  constructor(sheet){this.sheet=sheet;this.name='';this.set('idle')}
  set(name,{loop=true,onDone=null,events={}}={}){if(this.name===name)return;Object.assign(this,{name,i:0,t:0,loop,onDone,events,done:false})}
  get clip(){return this.sheet.meta.animations[this.name]}
  update(){const c=this.clip;if(this.done)return;if(++this.t>=60/c.fps){this.t=0;this.i++;if(this.events[this.i])this.events[this.i]();if(this.i>=c.frames){if(this.loop)this.i=0;else{this.i=c.frames-1;this.done=true;this.onDone&&this.onDone()}}}}
  draw(r,x,y,flip,o={}){const c=this.clip,m=this.sheet.meta,f=o.frame==null?this.i:o.frame;r.sprite(this.sheet.img,c.x[f],c.y,m.frameWidth,m.frameHeight,x,y,flip,m.anchor,o)}
}
