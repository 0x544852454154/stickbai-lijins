import {GROUND} from '../entities/Fighter.js';
export const STAGES=[
 {name:'THE RUINS',sky:['#1a0a1f','#4a1230','#8a2230','#c4452c','#f08a3c'],orb:{x:330,y:150,r:38,c:'#ffd27a'},far:'#3a1228',mid:'#220b1c',style:'pillar',ground:'#140812',line:'#7a2a2a',amb:'ember',ac:'#ff9a3c'},
 {name:'THE TEMPLE',sky:['#070b1e','#101a3c','#1c2a5c','#33407a','#5a6aa0'],orb:{x:120,y:60,r:22,c:'#e8eeff'},far:'#1b2550',mid:'#0d1230',style:'mount',ground:'#0a0d20',line:'#8a9ad8',amb:'petal',ac:'#ffb0cc'},
 {name:'THE VOID',sky:['#080014','#1a0438','#2d0a5c','#4a1090','#7a2cc0'],orb:{x:300,y:110,r:30,c:'#c070ff'},far:'#2a0a50',mid:'#150628',style:'rock',ground:'#0c0418',line:'#b060ff',amb:'mote',ac:'#d9a0ff'},
 {name:'NEON CITY',sky:['#02040c','#061428','#0a2a4a','#0e4a7a','#1a78b0'],orb:null,far:'#0a2038',mid:'#050f1e',style:'city',ground:'#060c18',line:'#30c8ff',amb:'rain',ac:'#8cd8ff'},
 {name:'SKY TEMPLE',sky:['#10141f','#252c44','#3c4668','#5a668c','#8a94b4'],orb:null,far:'#2c3452',mid:'#181e34',style:'cloud',ground:'#10131f',line:'#a0aed0',amb:'cloud',ac:'#c8d0e8'}];
export class Stage{
  constructor(d){Object.assign(this,d);this.t=0;let s=d.name.length*77;const rnd=()=>(s=(s*9301+49297)%233280)/233280;
    this.cols=[0,1].map(l=>Array.from({length:70},(_,i)=>{const b=l?60:100;return d.style==='city'?b*.5+rnd()*b*(l?.8:1.2):d.style==='pillar'?(i%5<2?b*.4+rnd()*b:b*.3):d.style==='rock'?(rnd()>.55?14+rnd()*40:0):d.style==='cloud'?(rnd()>.6?10+rnd()*40:5):b*.5+Math.sin(i*.35+l*2)*b*.4+rnd()*8}));
    this.p=Array.from({length:45},()=>({x:rnd()*480,y:rnd()*270,v:.3+rnd()}))}
  update(){this.t++;for(const p of this.p){const a=this.amb;p.y+=a==='ember'?-p.v*.6:a==='rain'?p.v*5:a==='petal'?p.v*.5:a==='cloud'?0:Math.sin(this.t*.02+p.x)*.2;p.x+=a==='petal'?p.v*.8:a==='rain'?-1:a==='cloud'?p.v*.3:.1;if(p.y<-4)p.y=270;if(p.y>270)p.y=-4;if(p.x>484)p.x=-4;if(p.x<-4)p.x=484}}
  draw(r,cam){const n=this.sky.length,bh=Math.ceil(GROUND/n/1);for(let i=0;i<n;i++)r.rect(0,i*bh,480,bh+1,this.sky[i]);
    if(this.orb)r.circle(this.orb.x-cam*.05,this.orb.y,this.orb.r,this.orb.c);
    [[this.far,.2,0],[this.mid,.4,1]].forEach(([c,f,l])=>this.cols[l].forEach((h,i)=>{const x=i*16-cam*f;if(x<-16||x>480||!h)return;
      if(this.style==='rock')r.rect(x,60+(i*37)%90+l*30+Math.sin(this.t*.03+i)*3,16,h*.5,c);else r.rect(x,GROUND-h,16,h,c);
      if(this.style==='city'&&i%7===l)r.rect(x+2,GROUND-h+3,12,2,this.ac);
      if(this.style==='city')for(let w=0;w<3;w++)if((i*7+w*13+l)%5<2)r.rect(x+3+w*4,GROUND-h+10+w*9,2,3,this.ac)}));
    for(const p of this.p){const a=this.amb;r.rect(p.x,p.y,a==='rain'?1:a==='cloud'?28:2,a==='rain'?5:a==='cloud'?3:2,this.ac)}
    r.rect(0,GROUND,480,40,this.ground);r.rect(0,GROUND,480,2,this.line);for(let x=-(cam%24);x<480;x+=24)r.rect(x,GROUND+10,12,1,this.line);
    if(this.amb==='rain')r.rect(0,GROUND+2,480,3,'rgba(140,216,255,.15)')}
  drawFg(r,cam){r.rect(6-cam*1.3,170,14,100,'#05030a');r.rect(620-cam*1.3,170,14,100,'#05030a')}
}
