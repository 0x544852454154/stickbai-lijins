import {rand} from '../utils/math.js';
export class Particle{constructor(){this.on=false}
  init(x,y,vx,vy,life,color,size,g){Object.assign(this,{x,y,vx,vy,life,max:life,color,size,g,on:true})}
  step(){this.x+=this.vx;this.y+=this.vy;this.vy+=this.g;if(--this.life<=0)this.on=false}}
export class VFXSystem{
  constructor(n=500){this.pool=Array.from({length:n},()=>new Particle());this.rings=[];this.shake=0;this.flash=0}
  emit(x,y,vx,vy,life,c,s=2,g=.1){const p=this.pool.find(p=>!p.on);if(p)p.init(x,y,vx,vy,life,c,s,g)}
  burst(x,y,c,n,sp,g=.1,s=2){for(let i=0;i<n;i++){const a=rand(0,6.28),v=rand(.3,1)*sp;this.emit(x,y,Math.cos(a)*v,Math.sin(a)*v,rand(12,26),i%3?c:'#fff',s,g)}}
  ring(x,y,c,max=40){this.rings.push({x,y,r:2,max,c})}
  slash(x,y,f,c,len=40){for(let i=0;i<14;i++){const t=i/13,a=-1+t*2;this.emit(x+f*(Math.cos(a)*len*.5+len*.3),y+Math.sin(a)*len*.55,0,0,8+((t*6)|0),i%4?c:'#fff',3,0)}}
  bolt(x,y,f,c,len=50){let py=y;for(let i=0;i<len;i+=4){py+=rand(-6,6);this.emit(x+f*i,py,0,0,9,i%8?c:'#fff',2,0)}}
  crack(x,c){for(let i=-30;i<=30;i+=3)this.emit(x+i,230+(Math.abs(i)%7)*.4,0,0,40,i%2?c:'#222',2,0)}
  hit(x,y,cfg,heavy){this.burst(x,y,cfg.color,heavy?18:9,heavy?4:2.5,.12,heavy?3:2);if(cfg.fx==='fire')this.burst(x,y,cfg.accent,6,2,-.08);if(cfg.fx==='bolt')this.bolt(x-10,y,1,cfg.accent,24);if(cfg.fx==='void'||heavy)this.ring(x,y,cfg.color,heavy?34:20)}
  update(){for(const p of this.pool)if(p.on)p.step();this.rings=this.rings.filter(r=>(r.r+=3)<r.max);this.shake*=.85;if(this.shake<.3)this.shake=0;if(this.flash>0)this.flash--}
  draw(r){for(const p of this.pool)if(p.on)r.rect(p.x,p.y,p.size,p.size,p.color);
    for(const q of this.rings)for(let a=0;a<6.28;a+=.35)r.rect(q.x+Math.cos(a)*q.r,q.y+Math.sin(a)*q.r*.4,3,3,q.c)}
}
