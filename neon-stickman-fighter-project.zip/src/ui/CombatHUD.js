export class CombatHUD{
  constructor(g){this.g=g}
  bar(r,f,left){const w=176,x=left?38:480-38-w,y=8,p=f.hp/f.maxHp,d=f.dispHp/f.maxHp;r.rect(x-2,y-2,w+4,14,'#000');r.rect(x,y,w,10,'#2a1020');
    const bx=(v)=>left?x:x+w-v*w;r.rect(bx(d),y,d*w,10,'#fff');r.rect(bx(p),y,p*w,10,f.cfg.color);r.rect(bx(p),y,p*w,3,f.cfg.accent);
    const m=f.meter/100,full=f.meter>=100&&(this.g.t>>3)%2;r.rect(x,y+14,w*.6,4,'#000');r.rect(left?x:x+w-w*.6*m,y+14,w*.6*m,4,full?'#fff':'#ffd040');
    r.text(f.cfg.name,left?x:x+w,y+22,f.cfg.color,8,left?'left':'right');
    const px=left?4:480-34,sh=this.g.assets.sheets[f.cfg.id],m2=sh.meta;r.rect(px-1,3,32,28,'#000');r.x.drawImage(sh.img,m2.animations.idle.x[0]+32,10,30,26,px,4,30,26);r.box(px-1,3,31,27,f.cfg.color)}
  draw(r,fs){const rm=fs.rm,t=fs.g.t;fs.f1.dispHp+=(fs.f1.hp-fs.f1.dispHp)*.08;fs.f2.dispHp+=(fs.f2.hp-fs.f2.dispHp)*.08;
    this.bar(r,fs.f1,true);this.bar(r,fs.f2,false);
    r.rect(216,4,48,24,'#000');r.text(rm.training?'--':String(Math.max(0,rm.time)).padStart(2,'0'),240,8,rm.time<=10&&!rm.training?'#ff3050':'#fff',16,'center');
    for(let s=0;s<2;s++)for(let i=0;i<rm.need&&!rm.training;i++)r.rect(s?250+i*10:222-i*10+(0),32,6,6,i<rm.wins[s]?'#ffd040':'#2a2040');
    [[fs.f1,12],[fs.f2,380]].forEach(([f,x],i)=>{const o=i?fs.f1:fs.f2,c=(i?fs.f2:fs.f1).combo;if(c.hits>=2){r.text(c.hits+' HITS',x,70,'#ffd040',12);r.text('DMG '+c.dmg,x,86,'#fff',8)}});
    if(rm.phase==='intro')r.text(rm.t<55?(fs.o.boss&&rm.round===1?'FINAL BOSS':'ROUND '+rm.round):'FIGHT!',240,110,rm.t<55?'#fff':'#ff3050',24,'center');
    if(rm.phase==='ko'||rm.phase==='end')r.text(rm.rw<0?'DRAW':(fs.o.timeout?'TIME':'K.O.'),240,110,'#ff3050',32,'center');
    if(rm.training){r.text('TRAINING  BKSP=RESET  ESC=MENU',240,258,'#8a86a8',6,'center');r.text('LAST HIT '+fs.f2.lastHit+'   COMBO '+fs.f1.combo.hits+' / '+fs.f1.combo.dmg,240,246,'#30e8ff',6,'center')}
    if(fs.vfx.flash>0)r.rect(0,0,480,270,`rgba(255,255,255,${fs.vfx.flash/14})`)}
}
