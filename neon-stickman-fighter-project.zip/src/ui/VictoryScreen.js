import {Screen} from './Screen.js';
import {CharacterSelect} from './CharacterSelect.js';
import {FightState} from './FightState.js';
export class VictoryScreen extends Screen{
  constructor(g,fs){super(g,0);this.fs=fs;const o=fs.o;this.w=fs.rm.winner;this.c=o.campaign;this.won=o.human2||this.w===0;
    this.win=this.w===0?fs.f1:fs.f2;this.cleared=!!(this.won&&this.c&&this.c.arcade&&this.c.n>=3);
    this.title=o.human2?'PLAYER '+(this.w+1)+' WINS':this.won?(this.cleared?'LEGEND!':'YOU WIN'):'GAME OVER'}
  update(){const k=this.g.input,g=this.g,c=this.c;this.t++;g.audio;
    if(k.menu('back')){g.states.go(new g.ui.MainMenu(g));return}
    if(this.t>30&&k.menu('ok')){
      if(this.fs.o.human2)g.states.go(new FightState(g,this.fs.o));
      else if(this.won&&c&&!this.cleared){c.n++;c.carry=this.fs.f1.hp+this.fs.f1.maxHp*.3;g.states.go(new FightState(g,c.options()))}
      else g.states.go(new g.ui.MainMenu(g))}}
  render(r){this.background(r);r.rect(0,0,480,270,'rgba(5,0,15,.7)');r.text(this.title,240,40,this.won?'#ffd040':'#ff3050',22,'center');
    this.big(r,this.win.cfg.id,240,200,4,false);r.text(this.win.cfg.name,240,215,this.win.cfg.color,12,'center');
    if(this.c)r.text((this.c.arcade?'STAGE ':'STREAK ')+(this.c.n+1),240,80,'#fff',8,'center');
    r.text(this.fs.o.human2?'ENTER = REMATCH   ESC = MENU':this.won&&!this.cleared?'ENTER = NEXT FIGHT':'ENTER = MENU',240,250,'#8a86a8',7,'center')}
}
