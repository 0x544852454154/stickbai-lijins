import {Screen} from './Screen.js';
import {ACTIONS} from '../input/ControlSettingsManager.js';
import {clamp} from '../utils/math.js';
export class SettingsMenu extends Screen{
  constructor(g){super(g,2);this.i=0}
  update(){const k=this.g.input,s=this.g.settings,o=s.opt,rows=['music','sfx','shake','fullscreen','quality','restore','back'];this.t++;
    if(k.menu('up'))this.i=(this.i+6)%7;if(k.menu('down'))this.i=(this.i+1)%7;
    const d=(k.menu('right')?1:0)-(k.menu('left')?1:0),r=rows[this.i];
    if(d&&(r==='music'||r==='sfx'||r==='shake')){o[r]=clamp(Math.round((o[r]+d*.1)*10)/10,0,r==='shake'?2:1);s.save();this.g.audio.sfx('blip')}
    if(d&&r==='quality'){o.quality=1-o.quality;s.save()}
    if(k.menu('ok')){if(r==='fullscreen'){document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen().catch(()=>{})}
      if(r==='restore'){s.restore();s.save()}if(r==='back')k.pr.add('Escape')}
    if(k.menu('back'))this.g.states.go(new this.g.ui.MainMenu(this.g))}
  render(r){this.background(r);r.rect(0,0,480,270,'rgba(5,0,15,.75)');r.text('SETTINGS',240,16,'#fff',14,'center');const o=this.g.settings.opt;
    const v=['MUSIC  '+Math.round(o.music*100)+'%','SFX    '+Math.round(o.sfx*100)+'%','SCREEN SHAKE  '+Math.round(o.shake*100)+'%','FULLSCREEN','PIXEL SCALE  '+(o.quality?'INTEGER (CRISP)':'FIT'),'RESTORE DEFAULTS','BACK'];
    v.forEach((t,i)=>{r.text(t,240,60+i*24,i===this.i?'#fff':'#8a86a8',10,'center');if(i===this.i)this.cursor(r,70,61+i*24)})}
}
export class ControlsMenu extends Screen{
  constructor(g){super(g,3);this.p=0;this.i=0;this.cap=false;this.msg=''}
  update(){const k=this.g.input,s=this.g.settings;this.t++;
    if(this.cap){if(k.last){if(k.last!=='Escape'){const res=s.rebind(this.p,ACTIONS[this.i],k.last);this.msg=res.conflict?'USED BY '+res.conflict:res.swapped?'SWAPPED WITH '+res.swapped.toUpperCase():'BOUND'}this.cap=false}return}
    if(k.menu('up'))this.i=(this.i+ACTIONS.length)%(ACTIONS.length+1);if(k.menu('down'))this.i=(this.i+1)%(ACTIONS.length+1);
    if(k.menu('left')||k.menu('right'))this.p=1-this.p;
    if(k.menu('ok')){if(this.i===ACTIONS.length){s.bind=JSON.parse(JSON.stringify(s.bind));s.restore();s.save();this.msg='DEFAULTS RESTORED'}else{this.cap=true;this.msg='PRESS A KEY...'}}
    if(k.menu('back'))this.g.states.go(new this.g.ui.MainMenu(this.g))}
  render(r){this.background(r);r.rect(0,0,480,270,'rgba(5,0,15,.8)');r.text('CONTROLS  P'+(this.p+1)+'  (<- ->)',240,8,'#fff',10,'center');const b=this.g.settings.bind[this.p];
    ACTIONS.forEach((a,i)=>{const y=28+i*16,on=i===this.i;r.text(a.toUpperCase(),130,y,on?'#fff':'#8a86a8',8);r.text(on&&this.cap?'...':b[a].replace('Key','').replace('Arrow','ARR '),350,y,on?'#ffd040':'#aaa',8,'right')});
    r.text('RESTORE DEFAULTS',130,28+ACTIONS.length*16,this.i===ACTIONS.length?'#fff':'#8a86a8',8);r.text(this.msg,240,250,'#30e8ff',8,'center')}
}
export class Credits extends Screen{
  constructor(g){super(g,4)}
  update(){if(this.g.input.menu('back')||this.g.input.menu('ok'))this.g.states.go(new this.g.ui.MainMenu(this.g))}
  render(r){this.background(r);r.rect(0,0,480,270,'rgba(5,0,15,.75)');r.text('CREDITS',240,30,'#fff',14,'center');
    ['NEON STICKMAN FIGHTER','FIGHTER SPRITES: SUPPLIED SHEETS','(CLEANED + RESLICED IN-PROJECT)','ENGINE, AI, STAGES, VFX, AUDIO: CODE','THANKS FOR PLAYING'].forEach((t,i)=>r.text(t,240,80+i*22,'#cfc8ff',8,'center'))}
}
