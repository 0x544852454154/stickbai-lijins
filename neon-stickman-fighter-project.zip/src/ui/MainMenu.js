import {Screen} from './Screen.js';
import {SettingsMenu,ControlsMenu,Credits} from './SettingsMenu.js';
import {CharacterSelect} from './CharacterSelect.js';
const ITEMS=['ARCADE','VERSUS','TRAINING','SURVIVAL','SETTINGS','CONTROLS','CREDITS'];
export class MainMenu extends Screen{
  constructor(g){super(g,0);this.i=0}
  update(){const k=this.g.input,a=this.g.audio;this.t++;
    if(k.menu('up')){this.i=(this.i+ITEMS.length-1)%ITEMS.length;a.sfx('blip')}
    if(k.menu('down')){this.i=(this.i+1)%ITEMS.length;a.sfx('blip')}
    if(k.menu('ok')){a.sfx('ok');const m=ITEMS[this.i],go=s=>this.g.states.go(s);
      if(m==='SETTINGS')go(new SettingsMenu(this.g));else if(m==='CONTROLS')go(new ControlsMenu(this.g));else if(m==='CREDITS')go(new Credits(this.g));else go(new CharacterSelect(this.g,m.toLowerCase()))}}
  render(r){this.background(r);r.rect(0,0,480,270,'rgba(5,0,15,.35)');
    const c=['#30e8ff','#ff3070','#b050ff'][(this.t>>5)%3];
    r.text('NEON',240,18,c,28,'center','#400a50');r.text('STICKMAN',240,50,'#fff',24,'center',c);r.text('FIGHTER: PIXEL EDITION',240,80,c,8,'center');
    r.text('FIGHT. SURVIVE. BECOME LEGEND.',240,94,'#ffd040',6,'center');
    ITEMS.forEach((m,i)=>{const y=112+i*17,on=i===this.i;r.text(m,240,y,on?'#fff':'#8a86a8',10,'center');if(on)this.cursor(r,240-m.length*5-16+Math.sin(this.t*.2)*2,y+1)});
    r.text('ENTER / J = SELECT',240,258,'#8a86a8',6,'center')}
}
