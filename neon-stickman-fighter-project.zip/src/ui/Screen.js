import {Stage,STAGES} from '../stages/Stage.js';
import {CharacterManager} from '../characters/CharacterManager.js';
export class Screen{
  constructor(g,stage=0){this.g=g;this.t=0;this.bg=new Stage(STAGES[stage])}
  big(r,id,x,y,s,flip,fr){const sh=this.g.assets.sheets[id];this.anim=this.anim||{};const a=this.anim[id]=this.anim[id]||new (this.g.AnimCtor)(sh);a.set('idle');a.update();a.draw(r,x,y,flip,{sx:s,sy:s,frame:fr})}
  background(r){this.t++;this.bg.update();this.bg.draw(r,0);CharacterManager.ids.forEach((id,i)=>this.big(r,id,70+i*113,GROUND2,2,i>1,undefined))}
  cursor(r,x,y){if((this.t>>3)%2)r.rect(x,y,6,6,'#fff');r.rect(x+6,y+1,2,4,'#fff')}
}
const GROUND2=232;
