import {Screen} from './Screen.js';
import {CharacterManager} from '../characters/CharacterManager.js';
import {Campaign} from '../systems/Campaign.js';
import {FightState} from './FightState.js';
export class CharacterSelect extends Screen{
  constructor(g,mode){super(g,1);this.mode=mode;this.n=mode==='versus'?2:1;this.p=[{i:0,ok:false},{i:1,ok:false}]}
  update(){const k=this.g.input,ids=CharacterManager.ids;this.t++;
    if(k.menu('back')){const{MainMenu}=this.g.ui;this.g.states.go(new MainMenu(this.g));return}
    for(let s=0;s<this.n;s++){const p=this.p[s];
      if(!p.ok){if(k.hit(s,'left')){p.i=(p.i+3)%4;this.g.audio.sfx('blip')}if(k.hit(s,'right')){p.i=(p.i+1)%4;this.g.audio.sfx('blip')}if(k.hit(s,'lp')){p.ok=true;this.g.audio.sfx('ok')}}
      else if(k.hit(s,'block'))p.ok=false}
    if(this.p.slice(0,this.n).every(p=>p.ok)){const a=ids[this.p[0].i],st=Math.random()*5|0;
      if(this.mode==='versus')this.g.states.go(new FightState(this.g,{mode:'versus',p1:a,p2:ids[this.p[1].i],human2:true,stage:st,rounds:2}));
      else if(this.mode==='training')this.g.states.go(new FightState(this.g,{mode:'training',p1:a,p2:ids[(this.p[0].i+1)%4],human2:false,diff:'dummy',stage:st,rounds:99}));
      else{const c=new Campaign(this.mode,a);this.g.states.go(new FightState(this.g,c.options()))}}}
  render(r){this.background(r);r.rect(0,0,480,270,'rgba(5,0,15,.6)');r.text('SELECT FIGHTER',240,10,'#fff',12,'center');
    r.text(this.mode==='versus'?'P1: A/D + J     P2: ARROWS + NUM1':'A/D + J',240,26,'#8a86a8',6,'center');
    CharacterManager.ids.forEach((id,i)=>{const c=CharacterManager.get(id),x=24+i*112,y=44,sh=this.g.assets.sheets[id],m=sh.meta;
      r.rect(x,y,100,150,'#0a0618');r.box(x,y,100,150,'#3a3060');
      r.x.drawImage(sh.img,m.animations.idle.x[0],0,96,80,x+2,y+6,96,80);r.text(c.name,x+50,y+96,c.color,10,'center');r.text(c.title,x+50,y+110,c.accent,6,'center');
      r.text('HP '+c.hp,x+8,y+124,'#aaa',6);r.text('SPD '+c.speed,x+8,y+136,'#aaa',6)});
    this.p.slice(0,this.n).forEach((p,s)=>{const x=24+p.i*112+(s?50:0);r.box(x-2+s*0,42,102,154,s?'#ff3070':'#30e8ff');r.text('P'+(s+1)+(p.ok?' READY':''),24+p.i*112+50,200+s*12,s?'#ff3070':'#30e8ff',8,'center')});
    const c=CharacterManager.get(CharacterManager.ids[this.p[0].i]);r.text(`SPECIAL ${c.special.name}   ULT ${c.ultimate.name}`,240,250,c.accent,6,'center')}
}
