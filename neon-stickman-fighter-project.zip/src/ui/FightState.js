import {PlayerFighter} from '../entities/PlayerFighter.js';
import {CPUFighter} from '../ai/CPUFighter.js';
import {CharacterManager} from '../characters/CharacterManager.js';
import {Stage,STAGES} from '../stages/Stage.js';
import {VFXSystem} from '../effects/VFXSystem.js';
import {CombatSystem} from '../combat/CombatSystem.js';
import {CombatHUD} from './CombatHUD.js';
import {RoundManager} from '../systems/RoundManager.js';
import {GROUND} from '../entities/Fighter.js';
import {clamp} from '../utils/math.js';
export class FightState{
  constructor(g,o){this.g=g;this.o=o;this.audio=g.audio;const A=g.assets.sheets,C=CharacterManager;
    this.f1=new PlayerFighter(C.get(o.p1),A[o.p1],0,g.input);
    this.f2=o.human2?new PlayerFighter(C.get(o.p2),A[o.p2],1,g.input):new CPUFighter(C.get(o.p2),A[o.p2],1,o.diff,o.hpMul||1);
    this.stage=new Stage(STAGES[o.stage]);this.vfx=new VFXSystem();this.combat=new CombatSystem(this);this.hud=new CombatHUD(g);
    this.rm=new RoundManager(o.mode==='training',o.rounds||2);this.freeze=0;this.cam=0;this.prep()}
  prep(){this.f1.spawn(200);this.f2.spawn(440);if(this.o.carry&&this.rm.round===1)this.f1.hp=Math.min(this.f1.maxHp,this.o.carry);this.projectiles=[];this.locked=true}
  enter(){this.audio.sfx('bell')}
  update(){const g=this.g,k=g.input,{f1,f2,rm}=this;
    if(k.pr.has('Escape')){g.states.go(new g.ui.MainMenu(g));return}
    if(rm.training&&k.pr.has('Backspace')){this.prep();this.locked=false}
    if(this.freeze>0){this.freeze--;return}
    this.locked=rm.phase!=='fight';this.stage.update();
    for(const[f,o]of[[f1,f2],[f2,f1]]){this.opp=o;f.update(this)}
    if(!this.locked){this.combat.update()}
    this.projectiles.forEach(p=>p.update(this));this.projectiles=this.projectiles.filter(p=>!p.dead);
    if(f1.y>=GROUND&&f2.y>=GROUND){const d=f2.x-f1.x,m=24-Math.abs(d);if(m>0){const s=d>=0?1:-1;f1.x=clamp(f1.x-s*m/2,24,616);f2.x=clamp(f2.x+s*m/2,24,616)}}
    if(rm.training)for(const f of[f1,f2]){if(f.hp<f.maxHp*.3)f.hp=f.maxHp;f.meter=100}
    this.vfx.update();const e=rm.update(f1,f2);
    if(e==='ko'){this.audio.sfx('ko');this.o.timeout=rm.time<=0&&f1.hp>0&&f2.hp>0;const w=rm.rw===0?f1:rm.rw===1?f2:null;if(w&&w.hp>0&&w.state!=='attack')w.setState('win');this.freeze=10}
    if(e==='next'){this.prep()}
    if(e==='end')g.states.go(new g.ui.VictoryScreen(g,this));
    const mid=(f1.x+f2.x)/2;this.cam+=(clamp(mid-240,0,160)-this.cam)*.12}
  render(r){const sh=this.vfx.shake,c=this.cam|0;r.clear();this.stage.draw(r,c);r.begin(c,(Math.random()-.5)*sh*2,(Math.random()-.5)*sh*2);
    [this.f1,this.f2].sort((a,b)=>(a.state==='attack')-(b.state==='attack')).forEach(f=>f.render(r));this.projectiles.forEach(p=>p.draw(r));this.vfx.draw(r);
    if(this.rm.training)for(const f of[this.f1,this.f2]){const h=f.hurtbox();r.box(h.x,h.y,h.w,h.h,'#3f6');if(f.active){const b=f.hitbox();r.box(b.x,b.y,b.w,b.h,'#f33')}}
    r.end();this.stage.drawFg(r,c);this.hud.draw(r,this);r.text(this.stage.name,240,40,'#6a6490',6,'center')}
}
