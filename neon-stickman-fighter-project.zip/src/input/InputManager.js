export class InputManager{
  constructor(s){this.s=s;this.down=new Set();this.pr=new Set();this.last=null;
    addEventListener('keydown',e=>{if(!e.repeat){this.pr.add(e.code);this.last=e.code}this.down.add(e.code);if(e.code.startsWith('Arrow')||e.code==='Space'||e.code.startsWith('Numpad'))e.preventDefault()});
    addEventListener('keyup',e=>this.down.delete(e.code));addEventListener('blur',()=>this.down.clear())}
  held(p,a){return this.down.has(this.s.bind[p][a])}
  hit(p,a){return this.pr.has(this.s.bind[p][a])}
  menu(n){const m={up:['ArrowUp','KeyW'],down:['ArrowDown','KeyS'],left:['ArrowLeft','KeyA'],right:['ArrowRight','KeyD'],ok:['Enter','Space','KeyJ','Numpad1'],back:['Escape','Backspace']};return m[n].some(k=>this.pr.has(k))}
  endFrame(){this.pr.clear();this.last=null}
}
