const DEF=[{left:'KeyA',right:'KeyD',up:'KeyW',down:'KeyS',lp:'KeyJ',hp:'KeyK',lk:'KeyU',hk:'KeyI',sp:'KeyL',ult:'KeyO',block:'KeyH'},
{left:'ArrowLeft',right:'ArrowRight',up:'ArrowUp',down:'ArrowDown',lp:'Numpad1',hp:'Numpad2',lk:'Numpad4',hk:'Numpad5',sp:'Numpad6',ult:'Numpad3',block:'Numpad0'}];
export const ACTIONS=Object.keys(DEF[0]);
export class ControlSettingsManager{
  constructor(){this.key='nsf.settings.v1';this.restore();this.load()}
  restore(){this.bind=JSON.parse(JSON.stringify(DEF));this.opt={music:.5,sfx:.7,shake:1,quality:1}}
  load(){try{const d=JSON.parse(localStorage.getItem(this.key));if(d){Object.assign(this.bind[0],d.bind&&d.bind[0]);Object.assign(this.bind[1],d.bind&&d.bind[1]);Object.assign(this.opt,d.opt)}}catch(e){}}
  save(){try{localStorage.setItem(this.key,JSON.stringify({bind:this.bind,opt:this.opt}))}catch(e){}}
  // Duplicate within a player swaps the two actions; a key owned by the other player is refused.
  rebind(p,action,code){const oa=ACTIONS.find(a=>this.bind[1-p][a]===code);if(oa)return{conflict:`P${2-p} ${oa.toUpperCase()}`};
    const d=ACTIONS.find(a=>a!==action&&this.bind[p][a]===code);if(d)this.bind[p][d]=this.bind[p][action];this.bind[p][action]=code;this.save();return{swapped:d}}
}
