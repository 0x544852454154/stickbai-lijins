import {Fighter,GROUND} from '../entities/Fighter.js';
const D={easy:{react:26,blk:.2},normal:{react:14,blk:.5},hard:{react:6,blk:.8},dummy:null};
export class CPUFighter extends Fighter{
  constructor(cfg,sheet,slot,diff='normal',hpMul=1){super(cfg,sheet,slot);this.d=D[diff];this.hpMul=hpMul;this.spawn(440);this.ai='IDLE';this.at=0}
  getIntent(g){const o=g.opp,dx=o.x-this.x,dist=Math.abs(dx),to=Math.sign(dx),it={mx:0,jump:false,down:false,block:false,acts:[]};
    if(!this.d)return it;if(--this.at<=0)this.think(dist,o);
    switch(this.ai){
      case 'APPROACH':it.mx=to;break;case 'RETREAT':it.mx=-to;break;case 'BLOCK':it.block=true;break;
      case 'JUMP':if(this.y>=GROUND)it.jump=true;it.mx=to;break;
      case 'ATTACK':case 'COUNTER':it.acts.push(['lp','lk','hp','hk'][Math.random()*4|0]);this.ai='RECOVER';break;
      case 'SPECIAL':it.acts.push(this.meter>=100?'ult':'sp');this.ai='RECOVER';break}
    return it}
  think(dist,o){const d=this.d,r=Math.random();this.at=d.react+(Math.random()*10|0);
    if(!this.free){this.ai='RECOVER';return}
    if(o.state==='attack'&&dist<80&&r<d.blk){this.ai='BLOCK';this.at=16}
    else if(o.state==='attack'&&o.t>o.atk.startup+o.atk.active&&dist<70){this.ai='COUNTER';this.at=4}
    else if(this.meter>=100&&dist<90)this.ai='SPECIAL';
    else if(dist>150)this.ai=r<.25?(this.cfg.id==='volt'?'SPECIAL':'JUMP'):'APPROACH';
    else if(dist>60)this.ai=r<.6?'APPROACH':'IDLE';
    else if(this.hp<this.maxHp*.3&&r<.3)this.ai='RETREAT';
    else this.ai=r<.65?'ATTACK':r<.8?'BLOCK':'IDLE'}
}
