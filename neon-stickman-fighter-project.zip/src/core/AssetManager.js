export class AssetManager{
  constructor(){this.sheets={}}
  async load(ids){for(const n of ids){const e=window.__ASSETS&&window.__ASSETS[n];const src=e?e.png:`public/assets/characters/${n}.png`;const meta=e?e.meta:await (await fetch(`public/assets/animations/${n}.json`)).json();const img=new Image();img.src=src;await img.decode();this.sheets[n]={img,meta}}}
}
