export class GameStateManager{
  constructor(g){this.g=g;this.cur=null;this.wipe=0}
  go(s){this.cur=s;this.wipe=22;s.enter&&s.enter()}
}
