export class Renderer{
  constructor(canvas,w=480,h=270){this.c=canvas;this.w=w;this.h=h;canvas.width=w;canvas.height=h;this.x=canvas.getContext('2d');this.x.imageSmoothingEnabled=false}
  clear(c='#000'){this.rect(0,0,this.w,this.h,c)}
  rect(x,y,w,h,c){this.x.fillStyle=c;this.x.fillRect(x|0,y|0,w|0,h|0)}
  box(x,y,w,h,c){this.x.strokeStyle=c;this.x.lineWidth=1;this.x.strokeRect((x|0)+.5,(y|0)+.5,w|0,h|0)}
  circle(cx,cy,r,c){for(let dy=-r;dy<=r;dy++){const w=Math.sqrt(r*r-dy*dy)|0;this.rect(cx-w,cy+dy,w*2,1,c)}}
  text(s,x,y,c='#fff',size=8,al='left',sh='#000'){const k=this.x;k.font=`${size}px "Press Start 2P",monospace`;k.textAlign=al;k.textBaseline='top';if(sh){k.fillStyle=sh;k.fillText(s,(x|0)+1,(y|0)+1)}k.fillStyle=c;k.fillText(s,x|0,y|0)}
  begin(cx,sx=0,sy=0){this.x.save();this.x.translate((-cx+sx)|0,sy|0)}
  end(){this.x.restore()}
  sprite(img,sx,sy,sw,sh,x,y,flip,anc,o={}){const c=this.x,dy=o.dy||0;c.save();c.translate(x|0,(y+dy)|0);if(o.rot)c.rotate(o.rot*(flip?-1:1));c.scale((flip?-1:1)*(o.sx||1),o.sy||1);if(o.alpha!=null)c.globalAlpha=o.alpha;if(o.filter)c.filter=o.filter;c.drawImage(img,sx,sy,sw,sh,-anc[0],-anc[1]-dy,sw,sh);c.restore()}
}
