import {Renderer} from './Renderer.js';
import {GameLoop} from './GameLoop.js';
import {AssetManager} from './AssetManager.js';
import {GameStateManager} from './GameStateManager.js';
import {ControlSettingsManager} from '../input/ControlSettingsManager.js';
import {InputManager} from '../input/InputManager.js';
import {AudioManager} from '../systems/AudioManager.js';
import {CharacterManager} from '../characters/CharacterManager.js';
import {SpriteAnimator} from '../animation/SpriteAnimator.js';
import {MainMenu} from '../ui/MainMenu.js';
import {VictoryScreen} from '../ui/VictoryScreen.js';
export class Game{
  constructor(canvas){this.settings=new ControlSettingsManager();this.input=new InputManager(this.settings);this.r=new Renderer(canvas);this.assets=new AssetManager();this.audio=new AudioManager(this.settings);
    this.states=new GameStateManager(this);this.t=0;this.AnimCtor=SpriteAnimator;this.ui={MainMenu,VictoryScreen};this.loop=new GameLoop(()=>this.update(),()=>this.render())}
  async start(){await this.assets.load(CharacterManager.ids);this.states.go(new MainMenu(this));this.loop.start()}
  update(){this.t++;if(this.input.pr.size)this.audio.unlock();this.states.cur.update();this.input.endFrame()}
  render(){const r=this.r,s=this.states;s.cur.render(r);if(s.wipe>0){const h=(s.wipe--/22)*135;r.rect(0,0,480,h,'#000');r.rect(0,270-h,480,h,'#000')}}
}
