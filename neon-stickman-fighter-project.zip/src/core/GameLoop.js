export class GameLoop{
  constructor(update,render){this.u=update;this.r=render;this.acc=0;this.last=0;this.step=1000/60}
  start(){const f=t=>{this.acc+=Math.min(100,t-(this.last||t));this.last=t;while(this.acc>=this.step){this.u();this.acc-=this.step}this.r();requestAnimationFrame(f)};requestAnimationFrame(f)}
}
