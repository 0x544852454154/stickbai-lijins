export class Attack{
  constructor(o){Object.assign(this,{startup:5,active:3,recovery:8,damage:40,hit:{x:10,y:-45,w:28,h:14},kb:3,hitstun:14,blockstun:9,meter:6,lunge:0,knockdown:false,low:false,rank:1,special:false},o)}
  get total(){return this.startup+this.active+this.recovery}
  variant(k){const a=new Attack(this);a.hit={...this.hit};
    if(k==='crouch'){a.low=true;a.hit.y=-24;a.hit.h=14;a.damage*=.9;a.recovery+=2;if(this.rank===4)a.knockdown=true}
    if(k==='air'){a.startup=Math.max(3,a.startup-3);a.hit={x:6,y:-44,w:34,h:40};a.recovery=10}return a}
  onActive(f,g){}
}
