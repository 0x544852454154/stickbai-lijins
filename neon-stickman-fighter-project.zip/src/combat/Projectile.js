import {Hitbox} from './Hitbox.js';
export class Projectile{
  constructor(o,a){this.o=o;this.a=a;this.p=a.proj;this.face=o.face;this.x=o.x+o.face*24;this.y=o.y-40;this.life=this.p.life;this.dead=false}
  update(fs){this.x+=this.face*this.p.speed;if(--this.life<=0||this.x<-20||this.x>660)this.dead=true;
    fs.vfx.emit(this.x-this.face*6,this.y+((Math.random()*10)|0)-5,0,0,10,this.o.cfg.color,2,0);
    const d=this.o===fs.f1?fs.f2:fs.f1;
    if(!['knockdown','getup','ko'].includes(d.state)&&new Hitbox(this.x-this.p.w/2,this.y-this.p.h/2,this.p.w,this.p.h).overlaps(d.hurtbox())){this.dead=true;fs.combat.apply(this.o,d,this.a,this.face,true)}}
  draw(r){const c=this.o.cfg,w=this.p.w,h=this.p.h;r.rect(this.x-w/2,this.y-h/2,w,h,c.color);r.rect(this.x-w/4,this.y-h/4,w/2,h/2,'#fff');r.rect(this.x-w/2-this.face*8,this.y-2,8,4,c.accent)}
}
