import {Attack} from './Attack.js';
import {Projectile} from './Projectile.js';
export class SpecialMove extends Attack{
  constructor(o){super({special:true,rank:5,meter:10,...o})}
  onActive(f,g){const c=f.cfg,v=g.vfx,x=f.x+f.face*20,y=f.y-38;g.audio.sfx('special');
    if(this.proj)g.projectiles.push(new Projectile(f,this));
    if(c.fx==='slash')v.slash(x,y,f.face,c.color,46);
    if(c.fx==='fire'){v.ring(f.x+f.face*30,f.y,c.color,50);v.crack(f.x+f.face*30,c.color);v.burst(x,y,c.accent,14,2.5,-.05)}
    if(c.fx==='bolt')v.bolt(x,y,f.face,c.color,this.proj?30:60);
    if(c.fx==='void'){v.burst(f.x,y,c.color,14,1.5,0);v.slash(x,y,f.face,c.accent,50)}}
}
export class UltimateAbility extends SpecialMove{
  constructor(o){super({rank:6,...o})}
  onActive(f,g){super.onActive(f,g);g.vfx.ring(f.x,f.y-30,f.cfg.accent,90);g.vfx.shake=10;g.vfx.burst(f.x,f.y-30,f.cfg.accent,30,4,0)}
}
