import {GROUND} from '../entities/Fighter.js';
import {ComboSystem} from './ComboSystem.js';
export class CombatSystem{
  constructor(fs){this.fs=fs;this.combos=new ComboSystem()}
  update(){const{f1,f2}=this.fs;for(const[a,d]of[[f1,f2],[f2,f1]]){this.check(a,d);this.combos.update(a,d)}}
  check(a,d){const at=a.atk;if(!a.active||a.hitDone||at.proj||['knockdown','getup','ko'].includes(d.state))return;
    if(a.hitbox().overlaps(d.hurtbox())){a.hitDone=true;this.apply(a,d,at,a.face,false)}}
  apply(a,d,at,face,proj){const fs=this.fs,v=fs.vfx,hx=d.x-face*6,hy=d.y-(d.crouching?20:38),heavy=at.rank>=3;
    if(d.canBlock(face,at)){d.hp=Math.max(1,d.hp-at.damage*.08);d.stunFor('blockstun',at.blockstun);d.vx=face*at.kb*.9;if(!proj){a.vx=-face*2.2;a.connected=true}
      v.burst(hx,hy,'#9cf',6,2,.1);fs.audio.sfx('block');d.meter=Math.min(100,d.meter+3);return}
    const c=a.combo;if(!c.live){c.hits=0;c.dmg=0;c.live=true;c.end=0}c.hits++;
    const dmg=Math.round(at.damage*this.combos.scale({hits:c.hits-1})*a.cfg.power);c.dmg+=dmg;d.hp=Math.max(0,d.hp-dmg);d.lastHit=dmg;
    a.meter=Math.min(100,a.meter+at.meter);d.meter=Math.min(100,d.meter+at.meter*.6);if(!proj)a.connected=true;
    if(at.knockdown||d.hp<=0||d.y<GROUND)d.knock(face*at.kb*1.3);else{d.stunFor('hitstun',at.hitstun);d.vx=face*at.kb}
    if((d.x<=30||d.x>=610)&&!proj)a.vx=-face*at.kb*.6;
    v.hit(hx,hy,a.cfg,heavy||at.special);v.shake=(heavy?5:2)*fs.g.settings.opt.shake;fs.freeze=Math.max(fs.freeze,heavy?8:4);fs.audio.sfx(heavy?'heavy':'hit')}
}
