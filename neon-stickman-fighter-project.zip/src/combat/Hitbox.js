export class Hitbox{constructor(x,y,w,h){this.x=x;this.y=y;this.w=w;this.h=h}
  overlaps(o){return this.x<o.x+o.w&&o.x<this.x+this.w&&this.y<o.y+o.h&&o.y<this.y+this.h}}
export class Hurtbox extends Hitbox{}
