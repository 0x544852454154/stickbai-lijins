export class ComboSystem{
  update(a,d){const c=a.combo;if(c.live&&!['hitstun','knockdown'].includes(d.state)&&d.state!=='ko'){c.live=false;c.end=0}
    if(!c.live&&c.hits&&++c.end>70){c.hits=0;c.dmg=0}}
  scale(c){return Math.max(.4,1-.1*c.hits)}
}
