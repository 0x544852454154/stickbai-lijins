import {Attack} from '../combat/Attack.js';
import {SpecialMove,UltimateAbility} from '../combat/SpecialMove.js';
const B={lp:{startup:4,active:3,recovery:7,damage:35,hit:{x:10,y:-46,w:26,h:12},kb:2.5,hitstun:14,blockstun:9,rank:1,meter:5},
 lk:{startup:6,active:3,recovery:9,damage:45,hit:{x:10,y:-26,w:32,h:14},kb:3,hitstun:16,blockstun:10,rank:2},
 hp:{startup:9,active:4,recovery:14,damage:80,hit:{x:10,y:-48,w:32,h:16},kb:5,hitstun:22,blockstun:13,rank:3},
 hk:{startup:12,active:4,recovery:18,damage:100,hit:{x:8,y:-38,w:42,h:18},kb:6,hitstun:24,blockstun:15,knockdown:true,rank:4}};
const moves=(ds,dd=1)=>Object.fromEntries(Object.entries(B).map(([k,v])=>[k,new Attack({...v,startup:Math.max(3,v.startup+ds),damage:v.damage*dd})]));
const ROSTER={
 shadow:{id:'shadow',name:'SHADOW',title:'CRIMSON',color:'#e0204a',accent:'#ff7090',fx:'slash',hp:900,speed:2.3,run:4.2,power:.95,moves:moves(-1),
  special:new SpecialMove({name:'CRIMSON STRIKE',startup:8,active:6,recovery:16,damage:90,hit:{x:8,y:-44,w:52,h:22},lunge:5,kb:5,hitstun:24,blockstun:14}),
  ultimate:new UltimateAbility({name:'BLOOD REQUIEM',startup:20,active:10,recovery:28,damage:300,hit:{x:0,y:-60,w:90,h:70},lunge:4,kb:9,knockdown:true,hitstun:40,blockstun:20})},
 titan:{id:'titan',name:'TITAN',title:'INFERNO',color:'#ff8a1c',accent:'#ffd040',fx:'fire',hp:1100,speed:1.6,run:3,power:1.25,moves:moves(2,1.1),
  special:new SpecialMove({name:'IRON FIST',startup:16,active:4,recovery:22,damage:140,hit:{x:8,y:-48,w:46,h:22},kb:9,knockdown:true,hitstun:30,blockstun:16}),
  ultimate:new UltimateAbility({name:'APOCALYPSE',startup:24,active:8,recovery:30,damage:360,hit:{x:0,y:-70,w:110,h:80},kb:11,knockdown:true,hitstun:44,blockstun:22})},
 volt:{id:'volt',name:'VOLT',title:'TEMPEST',color:'#30b8ff',accent:'#b0f0ff',fx:'bolt',hp:900,speed:2,run:3.8,power:1,moves:moves(0),
  special:new SpecialMove({name:'ELECTRIC BURST',startup:10,active:2,recovery:22,damage:70,kb:4,hitstun:20,blockstun:12,proj:{speed:5.5,life:90,w:16,h:14}}),
  ultimate:new UltimateAbility({name:'OVERLOAD',startup:18,active:2,recovery:26,damage:290,kb:9,knockdown:true,hitstun:40,blockstun:20,proj:{speed:8,life:90,w:40,h:36}})},
 reaper:{id:'reaper',name:'REAPER',title:'VOID',color:'#b050ff',accent:'#e0a0ff',fx:'void',hp:950,speed:2.1,run:4,power:1.05,moves:moves(0,1.02),
  special:new SpecialMove({name:'PHANTOM SLASH',startup:7,active:5,recovery:14,damage:85,hit:{x:8,y:-46,w:56,h:24},lunge:9,kb:5,hitstun:24,blockstun:14}),
  ultimate:new UltimateAbility({name:"DEATH'S EMBRACE",startup:18,active:10,recovery:26,damage:330,hit:{x:0,y:-64,w:76,h:66},lunge:11,kb:9,knockdown:true,hitstun:40,blockstun:20})}};
export class CharacterManager{static get ids(){return Object.keys(ROSTER)}static get(id){return ROSTER[id]}}
