import {Fighter} from './Fighter.js';
export class PlayerFighter extends Fighter{
  constructor(cfg,sheet,slot,input){super(cfg,sheet,slot);this.input=input}
  getIntent(){const i=this.input,p=this.slot;return{mx:(i.held(p,'right')?1:0)-(i.held(p,'left')?1:0),jump:i.held(p,'up'),down:i.held(p,'down'),block:i.held(p,'block'),acts:['lp','hp','lk','hk','sp','ult'].filter(a=>i.hit(p,a))}}
}
