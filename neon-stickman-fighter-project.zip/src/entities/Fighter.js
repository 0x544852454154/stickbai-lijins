import {SpriteAnimator} from '../animation/SpriteAnimator.js';
import {Hitbox,Hurtbox} from '../combat/Hitbox.js';
import {clamp} from '../utils/math.js';
export const GROUND=230;
const FREE=['idle','walk','run','jump','crouch','block'],NEUTRAL={mx:0,jump:false,down:false,block:false,acts:[]},RANK={lp:1,lk:2,hp:3,hk:4,sp:5,ult:6};
export class Fighter{
  constructor(cfg,sheet,slot){this.cfg=cfg;this.slot=slot;this.anim=new SpriteAnimator(sheet);this.meter=0;this.dispHp=cfg.hp;this.hpMul=1;this.combo={hits:0,dmg:0,live:false,end:0};this.lastHit=0;this.spawn(0)}
  getIntent(g){throw new Error('abstract')}
  spawn(x){this.maxHp=this.cfg.hp*this.hpMul;Object.assign(this,{x,y:GROUND,vx:0,vy:0,face:x<240?1:-1,hp:this.maxHp,state:'idle',t:0,atk:null,hitDone:false,connected:false,buf:null,bufT:0,runT:0,stun:0,crouching:false});this.combo={hits:0,dmg:0,live:false,end:0}}
  setState(s){this.state=s;this.t=0}
  get free(){return FREE.includes(this.state)}
  hurtbox(){const h=this.crouching?36:58;return new Hurtbox(this.x-12,this.y-h,24,h)}
  hitbox(){const a=this.atk,b=a.hit;return new Hitbox(this.face>0?this.x+b.x:this.x-b.x-b.w,this.y+b.y,b.w,b.h)}
  get active(){return this.state==='attack'&&this.t>this.atk.startup&&this.t<=this.atk.startup+this.atk.active}
  canBlock(face,a){return(this.state==='block'||this.state==='blockstun')&&this.face===-face&&!(a.low&&!this.crouching)}
  stunFor(kind,n){this.atk=null;this.setState(kind);this.stun=n}
  knock(vx){this.atk=null;this.setState(this.hp<=0?'ko':'knockdown');this.vx=vx;this.vy=-6}
  start(act,g){let a;const air=this.y<GROUND;
    if(act==='sp'){if(air)return false;a=this.cfg.special}
    else if(act==='ult'){if(this.meter<100)return false;a=this.cfg.ultimate;this.meter=0;g.vfx.flash=10;g.freeze=18}
    else a=this.cfg.moves[act].variant(air?'air':this.crouching?'crouch':'');
    this.atk=a;this.atkAct=act;this.setState('attack');this.hitDone=false;this.connected=false;return true}
  update(g){const it=g.locked?NEUTRAL:this.getIntent(g),air=this.y<GROUND,s=this.state;this.t++;
    if(it.acts.length){this.buf=it.acts[0];this.bufT=10}else if(this.bufT>0&&--this.bufT<=0)this.buf=null;
    if(this.free&&!air)this.face=g.opp.x>=this.x?1:-1;
    if(s==='attack')this.doAttack(g);
    else if(s==='hitstun'||s==='blockstun'){this.vx*=.85;if(--this.stun<=0)this.setState(air?'jump':'idle')}
    else if(s==='knockdown'){this.vx*=.9;if(!air&&this.t>40)this.setState('getup')}
    else if(s==='getup'){if(this.t>18)this.setState('idle')}
    else if(s==='ko'||s==='win')this.vx*=.85;
    else this.control(it,g,air);
    this.x=clamp(this.x+this.vx,24,616);this.y+=this.vy;
    if(this.y<GROUND)this.vy+=.5;else{this.y=GROUND;this.vy=0}}
  control(it,g,air){const c=this.cfg;
    if(!air){this.crouching=!!it.down;
      if(it.block){if(this.state!=='block')this.setState('block');this.vx=0}
      else if(it.down){if(this.state!=='crouch')this.setState('crouch');this.vx=0}
      else if(it.jump){this.vy=-9.8;this.vx=it.mx*c.speed*1.1;this.setState('jump')}
      else if(it.mx){this.runT++;const w=this.runT>20?'run':'walk';this.vx=it.mx*(w==='run'?c.run:c.speed);if(this.state!==w)this.setState(w)}
      else{this.runT=0;this.vx=0;if(this.state!=='idle')this.setState('idle')}}
    else{this.crouching=false;if(this.state!=='jump')this.setState('jump')}
    if(this.buf){const a=this.buf;this.buf=null;this.start(a,g)}}
  doAttack(g){const a=this.atk,air=this.y<GROUND,on=this.t>a.startup&&this.t<=a.startup+a.active;
    if(this.t===a.startup+1)a.onActive(this,g);
    if(on&&a.lunge)this.vx=a.lunge*this.face;else if(!air)this.vx*=.6;
    if(this.buf&&this.connected&&this.t>a.startup&&RANK[this.buf]>RANK[this.atkAct]){const b=this.buf;this.buf=null;this.start(b,g);return}
    if(this.t>=a.total){this.atk=null;this.setState(air?'jump':'idle')}}
  // Placeholder poses are derived from the supplied idle/run frames (see README: no dedicated attack sheets were provided).
  render(r){const s=this.state,o={};let clip='idle',fr=null;
    switch(s){
      case 'walk':clip='walk';break;case 'run':clip='run';break;
      case 'jump':clip='run';fr=this.vy<0?2:5;break;
      case 'crouch':case 'getup':fr=0;o.sy=.75;break;
      case 'block':fr=2;o.filter='brightness(1.4)';if(this.crouching)o.sy=.8;break;
      case 'hitstun':fr=3;o.rot=-.12;if(this.t<4)o.filter='brightness(4)';break;
      case 'blockstun':fr=2;o.sx=.95;break;
      case 'knockdown':case 'ko':fr=0;o.rot=1.45;o.dy=-8;break;
      case 'win':fr=this.t%40<20?0:1;break;
      case 'attack':{clip='run';const a=this.atk,on=this.active;fr=this.t<=a.startup?2:on?(this.atkAct==='lk'||this.atkAct==='hk'?5:4):2;if(on)o.sx=1.08;if(a.special)o.filter=`drop-shadow(0 0 3px ${this.cfg.color})`;break}}
    r.rect(this.x-14,GROUND+1,28,3,'rgba(0,0,0,.5)');this.anim.set(clip);this.anim.update();this.anim.draw(r,this.x,this.y,this.face<0,{...o,frame:fr==null?undefined:fr});
    if(s==='block')r.rect(this.x+this.face*14-2,this.y-(this.crouching?30:46),4,26,this.cfg.accent)}
}
