// Headless smoke test: runs full CPU-vs-scripted-player fights for every character pairing with stubbed canvas/audio.
import fs from 'fs';
const noop=new Proxy(function(){},{get:(t,k)=>k==='measureText'?()=>({width:0}):noop,apply:()=>noop,set:()=>true});
globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.addEventListener=()=>{};globalThis.document={};globalThis.window=globalThis;
const {Renderer}=await import('../src/core/Renderer.js');
const {ControlSettingsManager,ACTIONS}=await import('../src/input/ControlSettingsManager.js');
const {InputManager}=await import('../src/input/InputManager.js');
const {FightState}=await import('../src/ui/FightState.js');
const {CharacterManager}=await import('../src/characters/CharacterManager.js');
let fails=0;const ok=(c,m)=>{if(!c){console.log('FAIL',m);fails++}else console.log('ok  ',m)};
const canvas={getContext:()=>noop};const r=new Renderer(canvas);
const sheets={};for(const id of CharacterManager.ids)sheets[id]={img:{},meta:JSON.parse(fs.readFileSync(`public/assets/animations/${id}.json`))};
const settings=new ControlSettingsManager(),input=new InputManager(settings);
const audio={sfx(){}};const g={settings,input,assets:{sheets},audio,t:0,ui:{VictoryScreen:class{}},states:{go(){}}};
// rebinding checks
ok(settings.rebind(0,'lp','KeyK').swapped==='hp','duplicate binding swaps within a player');
ok(!!settings.rebind(0,'lp','Numpad1').conflict,'key owned by other player is refused');
settings.restore();
let hits=0,maxCombo=0,ults=0,projs=0,ends=0;
for(const a of CharacterManager.ids)for(const b of CharacterManager.ids){
  const st=new FightState(g,{mode:'versus',p1:a,p2:b,human2:false,diff:'hard',stage:Math.random()*5|0,rounds:1});
  const keys=['lp','hp','lk','hk','sp','ult','up','down','block'];let held=null;
  for(let f=0;f<2500&&st.rm.phase!=='end';f++){
    g.t++;if(f%7===0){input.pr.clear();const a=keys[Math.random()*keys.length|0];input.pr.add(settings.bind[0][a]);held=Math.random()<.5?'right':'left'}
    input.down.clear();input.down.add(settings.bind[0][held==='right'?'right':'left']);
    st.f1.meter=Math.max(st.f1.meter,f%400===0?100:0);
    const h1=st.f2.hp;st.update();st.render(r);if(st.f2.hp<h1)hits++;maxCombo=Math.max(maxCombo,st.f1.combo.hits,st.f2.combo.hits);projs+=st.projectiles.length;
    if(isNaN(st.f1.x)||isNaN(st.f2.x)||isNaN(st.f1.hp))throw new Error('NaN state');
  }
  if(st.rm.phase==='end')ends++;
}
ok(hits>0,'attacks connect and reduce health ('+hits+' hits)');
ok(maxCombo>=2,'combo counter reaches '+maxCombo);
ok(projs>0,'projectiles spawn');
ok(ends>0,'rounds/matches finish ('+ends+'/16)');
process.exit(fails?1:0);
