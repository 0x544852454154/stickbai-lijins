"""Converts the supplied AI-generated sheets into real sprite sheets.
Steps: key out the baked checkerboard, find frames by column gaps, remove ground bar,
anchor feet (bottom-center on the bar), downscale to the game pixel grid, pack uniform cells."""
from PIL import Image
import numpy as np, json
from scipy import ndimage
U='/mnt/user-data/uploads/'
SRC={'reaper':'Gemini_Generated_Image_2ceunt2ceunt2ceu__3_.jfif','volt':'Gemini_Generated_Image_2ceunt2ceunt2ceu__2_.jfif',
     'shadow':'Gemini_Generated_Image_2ceunt2ceunt2ceu.jfif','titan':'Gemini_Generated_Image_2ceunt2ceunt2ceu__4_.jfif'}
ROWS=[('idle',6,(60,232),8),('walk',8,(300,482),10),('run',8,(556,726),14)]
CW,CH,S=96,80,0.4
for name,f in SRC.items():
    a=np.array(Image.open(U+f).convert('RGB')).astype(int)
    fg=~(((a.max(2)-a.min(2))<28)&(a.mean(2)>75))
    fg=ndimage.binary_opening(fg,iterations=1)
    rgba=np.dstack([a,fg*255]).astype(np.uint8)
    sheet=Image.new('RGBA',(CW*8,CH*3)); meta={'frameWidth':CW,'frameHeight':CH,'anchor':[CW//2,CH-4],'facing':'right','animations':{}}
    for r,(an,n,(y0,y1),fps) in enumerate(ROWS):
        band=fg[y0:y1]; cols=band.sum(0)>0
        lab,k=ndimage.label(ndimage.binary_dilation(cols[None,:],iterations=14)[0][None,:]&True)
        segs=[ (np.where(lab[0]==i)[0].min(),np.where(lab[0]==i)[0].max()) for i in range(1,k+1)]
        segs=[(max(0,s-0),e) for s,e in segs if cols[s:e+1].sum()>40]
        if len(segs)!=n:  # touching trails: cut at the emptiest column near each expected boundary
            cnt=band.sum(0).astype(float); xs=np.where(cols)[0]; lo,hi=xs.min(),xs.max()
            cuts=[lo]+[int(c-40+np.argmin(cnt[int(c-40):int(c+40)])) for c in [lo+(hi-lo)*i/n for i in range(1,n)]]+[hi]
            segs=[(cuts[i],cuts[i+1]-1) for i in range(n)]
        assert len(segs)==n,(name,an,len(segs))
        for i,(x0,x1) in enumerate(segs):
            sub=fg[y0:y1,x0:x1+1]
            rowsum=sub.sum(1); bar=[y for y in range(sub.shape[0]) if rowsum[y]>0.8*(sub.shape[1]*0.55) and y>sub.shape[0]*0.8]
            gy=min(bar) if bar else sub.shape[0]-1
            crop=rgba[y0:y0+gy,x0:x1+1].copy()          # everything above bar
            bx=(x0+x1)//2
            cx=int(np.mean(np.where(sub[max(0,gy-6):gy].any(0))[0])) if sub[max(0,gy-6):gy].any() else sub.shape[1]//2
            im=Image.fromarray(crop); w,h=im.size
            im=im.resize((max(1,round(w*S)),max(1,round(h*S))),Image.LANCZOS)
            al=np.array(im); al[...,3]=(al[...,3]>140)*255; im=Image.fromarray(al)
            cell=Image.new('RGBA',(CW,CH)); ox=CW//2-round(cx*S); oy=CH-4-im.size[1]
            cell.paste(im,(ox,oy),im); sheet.paste(cell,(i*CW,r*CH))
        meta['animations'][an]={'row':r,'frames':n,'fps':fps,'loop':True,'x':[i*CW for i in range(n)],'y':r*CH}
    sheet.save(f'public/assets/characters/{name}.png')
    json.dump(meta,open(f'public/assets/animations/{name}.json','w'),indent=1)
    bg=Image.new('RGBA',sheet.size,(70,70,90,255)); bg.alpha_composite(sheet); bg.save(f'/tmp/{name}_check.png')
    print(name,'ok')
