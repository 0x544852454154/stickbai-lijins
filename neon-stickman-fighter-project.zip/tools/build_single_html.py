"""Bundles src/ ES modules + sprite sheets into one self-contained HTML file."""
import re,base64,json
ORDER='utils/math core/GameLoop core/Renderer core/AssetManager core/GameStateManager input/ControlSettingsManager input/InputManager animation/SpriteAnimator combat/Hitbox combat/Attack combat/Projectile combat/SpecialMove characters/CharacterManager effects/VFXSystem entities/Fighter entities/PlayerFighter ai/CPUFighter combat/ComboSystem combat/CombatSystem stages/Stage systems/AudioManager systems/RoundManager systems/Campaign ui/Screen ui/SettingsMenu ui/CharacterSelect ui/CombatHUD ui/FightState ui/MainMenu ui/VictoryScreen core/Game main'.split()
code=[]
for m in ORDER:
    s=open(f'src/{m}.js').read()
    s=re.sub(r"^import .*?;\s*$","",s,flags=re.M); s=re.sub(r"^export ","",s,flags=re.M); code.append(s)
assets={n:{'png':'data:image/png;base64,'+base64.b64encode(open(f'public/assets/characters/{n}.png','rb').read()).decode(),'meta':json.load(open(f'public/assets/animations/{n}.json'))} for n in ['shadow','titan','volt','reaper']}
html=f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Neon Stickman Fighter</title>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
<style>:root{{--bg:#05030a;color-scheme:dark}}html,body{{height:100%;margin:0;background:var(--bg)}}
body{{display:flex;align-items:center;justify-content:center;overflow:hidden;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);box-sizing:border-box}}
canvas{{image-rendering:pixelated;image-rendering:crisp-edges;background:#000;max-width:100%}}</style></head>
<body><canvas id="game"></canvas><script>window.__ASSETS={json.dumps(assets)};</script>
<script>(()=>{{"use strict";\n{chr(10).join(code)}\n}})();</script></body></html>'''
import os;os.makedirs('dist',exist_ok=True);open('dist/neon-stickman-fighter.html','w').write(html)
open('dist/_bundle.js','w').write('\n'.join(code));print(len(html)//1024,'KB')
